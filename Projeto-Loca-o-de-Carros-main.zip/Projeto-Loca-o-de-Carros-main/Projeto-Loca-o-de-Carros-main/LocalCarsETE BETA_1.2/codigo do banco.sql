CREATE TABLE locacao_veiculos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    datanascimento DATE,
    telefone VARCHAR(15),
    estadocivil VARCHAR(20)
);
